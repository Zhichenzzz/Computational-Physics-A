//
// Created by HUAWEI on 2022/12/18.
//

#ifndef MAIN_CPP_SANDBOX_BOXCOUNTING_H
#define MAIN_CPP_SANDBOX_BOXCOUNTING_H


void Box_counting(int const p[][240]);
void Sandbox(const int p[][240]);
#endif //MAIN_CPP_SANDBOX_BOXCOUNTING_H
